package com.example.thirstcure

import android.R
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import com.example.thirstcure.databinding.FragmentSettingsBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*


class SettingsFragment : Fragment(), View.OnClickListener {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private val mFirebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()

    private var timeList = mutableListOf<String>()
    private var timeArrayAdapter: ArrayAdapter<String>? = null


    private val sharedPreferences: SharedPreferences by lazy {
        requireActivity().getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSettingsBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val isNotificationsEnabled = sharedPreferences.getBoolean("notifications_enabled", false)

        binding.btnSwitchNotification.isChecked = isNotificationsEnabled
        binding.btnAddTime.isEnabled = isNotificationsEnabled
        binding.lvTimes.isEnabled = isNotificationsEnabled
        binding.btnAddTime.isClickable = isNotificationsEnabled

        timeList = sharedPreferences.getStringSet("notification_times", setOf())?.toMutableList() ?: mutableListOf()
        timeArrayAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, timeList)
        binding.lvTimes.adapter = timeArrayAdapter

        binding.btnSwitchNotification.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("notifications_enabled", isChecked).apply()

            binding.btnAddTime.isEnabled = isChecked
            binding.lvTimes.isEnabled = isChecked
            binding.btnAddTime.isClickable = isChecked

            if (isChecked) {
                setNotifications()
            } else {
                cancelNotifications()
            }


        }

        binding.lvTimes?.onItemLongClickListener = AdapterView.OnItemLongClickListener { _, _, position, _ ->
            timeList.removeAt(position)
            sharedPreferences.edit().putStringSet("notification_times", timeList.toSet()).apply()
            timeArrayAdapter?.notifyDataSetChanged()

            if (binding.btnSwitchNotification.isChecked) {
                setNotifications()
            }

            true
        }

        binding.btnAddTime?.setOnClickListener {
            val calendar = Calendar.getInstance()
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val timePickerDialog = TimePickerDialog(this.requireContext(), TimePickerDialog.OnTimeSetListener { _, selectedHour, selectedMinute ->
                var selectedMinuteStr = selectedMinute.toString()
                if (selectedMinute < 10) {
                    selectedMinuteStr = "0$selectedMinute"
                }
                val selectedTime = "$selectedHour:$selectedMinuteStr"

                // Check if the time is already in the list
                if (!timeList.contains(selectedTime)) {
                    // Add the selected time to the list
                    timeList.add(selectedTime)
                    sharedPreferences.edit().putStringSet("notification_times", timeList.toSet()).apply()
                    timeArrayAdapter?.notifyDataSetChanged()
                    setNotifications()
                } else {
                    Snackbar.make(requireView(),"Diese Zeit befindet sich bereits in der Liste", Snackbar.LENGTH_LONG).show()
                }
            }, hour, minute, true)

            timePickerDialog.show()
        }

        loadSettings()

        //Fragebutton
        binding.btnQuestionLimit.setOnClickListener(this)
        binding.button2.setOnClickListener(this)
    }

    override fun onPause() {
        super.onPause()
        sharedPreferences.edit().putStringSet("notification_times", timeList.toSet()).apply()
    }

    override fun onResume() {
        super.onResume()
        timeList = sharedPreferences.getStringSet("notification_times", setOf())?.toMutableList() ?: mutableListOf()
        timeArrayAdapter?.notifyDataSetChanged()
    }

    private fun setNotifications() {
        val alarmManager = requireActivity().getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val notificationIntent = Intent(requireContext(), NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(requireContext(), 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT)

        // Create a notification channel for Android Oreo and higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "default_channel_id"
            val channelName = "Default Channel"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, channelName, importance)
            val notificationManager = requireActivity().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }

        // Set up notifications for each time in timeList
        for (timeString in timeList) {
            // Parse time string into hour and minute
            val (hour, minute) = timeString.split(":").map { it.toInt() }

            // Set up calendar object for the notification time
            val calendar = Calendar.getInstance().apply {
                timeInMillis = System.currentTimeMillis()
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                // If the time has already passed today, add one day to the notification date
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_MONTH, 1)
                }
            }

            // Set up the notification with the pending intent
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            }
        }
    }

    private fun cancelNotifications() {
        val alarmManager = requireActivity().getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val notificationIntent = Intent(requireContext(), NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(requireContext(), 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT)

        // Cancel all pending notifications
        alarmManager.cancel(pendingIntent)
    }


    override fun onClick(p0: View?) {
        when (p0?.id){
            binding.btnQuestionLimit.id -> {
                Snackbar.make(requireView(),"Geben Sie Hier die gewünschte tägliche Trinkmenge ein.", Snackbar.LENGTH_LONG)
                    .setAction("Tagesziel",null).show()
            }
            binding.button2.id ->{
                val limit:String = binding.editTextNumberDecimal.text.toString()
                saveSettings(limit)
            }
        }
    }

    private fun loadSettings() {
        val uid = mFirebaseAuth.currentUser!!.uid

        //Tagesziel
        db.collection("user").document(uid).collection("userSettings").document("dailyIntake")
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val doc = task.result
                    val intakeMax = doc.getString("daylimit")

                    binding.editTextNumberDecimal.setText(intakeMax)

                } else {
                    // Log.d(TAG, "FEHLER: Daten lesen ", task.exception)
                }
            }
    }

    private fun saveSettings(limit: String){
        val uid = mFirebaseAuth.currentUser!!.uid

        val Daylimit = userSettings()
        Daylimit.setDaylimit(limit)

        db.collection("user").document(uid).collection("userSettings").document("dailyIntake").set(Daylimit)
            .addOnSuccessListener { Toast.makeText(activity,"Erfolg", Toast.LENGTH_SHORT).show() }
            .addOnFailureListener{ Toast.makeText(activity,"fehler", Toast.LENGTH_SHORT).show() }

    }
}