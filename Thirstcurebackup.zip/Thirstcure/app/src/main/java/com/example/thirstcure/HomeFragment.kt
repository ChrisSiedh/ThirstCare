package com.example.thirstcure

import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.fragment.findNavController
import com.example.thirstcure.databinding.FragmentHomeBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class HomeFragment : Fragment(R.layout.fragment_home) {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val mFirebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentHomeBinding.inflate(inflater, container, false)


        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadDayReport()

        //FAB
        binding.fabDrink.setOnClickListener{

            val DrinksFragment = DrinksFragment()
            val transaction: FragmentTransaction = requireFragmentManager().beginTransaction()
            transaction.replace(R.id.fragmentContainerView,DrinksFragment)
            transaction.commit()

        }
    }


    private fun loadDayReport() {
        val uid = mFirebaseAuth.currentUser!!.uid
        val dateFormat = SimpleDateFormat ("d.M.yyyy")
        val currentDate = dateFormat.format(Date()).toString()

        // Tagesziel laden
        db.collection("user").document(uid).collection("userSettings").document("dailyIntake")
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val doc = task.result
                    val intakeMax = doc.getString("daylimit")

                    if (!intakeMax.isNullOrEmpty()) {
                        val progressmax = intakeMax.toInt() * 100
                        binding.progressBar.max = progressmax
                        binding.tvTargetLimit.text = "$intakeMax ml"
                        binding.textView5.text = intakeMax

                        // Update progress bar after both database requests have completed
                        updateProgressBar(uid, currentDate)
                    }
                } else {
                    // Log.d(TAG, "FEHLER: Daten lesen ", task.exception)
                }
            }
    }

    private fun updateProgressBar(uid: String, currentDate: String) {
        db.collection("user").document(uid).collection("userData").document(uid).collection(currentDate)
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    var fullval: Double = 0.0
                    val df = DecimalFormat("#")
                    for (document in task.result) {
                        var drinkval = document.getString("drinkValue")!!
                        fullval += (drinkval.toFloat())

                    }

                    binding.progressBar.progress = (fullval * 100).toInt()
                    binding.textView4.text = df.format(fullval).toString()

                } else {
                    // Log.d(TAG, "FEHLER: Daten lesen ", task.exception)
                }
            }
    }
}