package com.example.thirstcure
import android.R
import android.R.layout
import android.app.DatePickerDialog
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentTransaction
import com.example.thirstcure.databinding.FragmentAnalyticsBinding
import com.example.thirstcure.databinding.FragmentDrinksBinding
import com.example.thirstcure.databinding.FragmentHomeBinding
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.LegendEntry
import com.github.mikephil.charting.components.LimitLine
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IValueFormatter
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class AnalyticsFragment : Fragment(com.example.thirstcure.R.layout.fragment_analytics) {

    private var _binding: FragmentAnalyticsBinding? = null
    private val binding get() = _binding!!

    private val mFirebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()

    lateinit var barChart: BarChart
    lateinit var pieChart: PieChart

    private var chartType = "bar"


    private var startTimestamp = 0L
    private var endTimestamp = 0L

    private lateinit var startDate: String
    private lateinit var endDate: String

    private lateinit var startCalendar: Calendar
    private lateinit var endCalendar: Calendar

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentAnalyticsBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        barChart = binding.barChart
        pieChart = binding.pieChart

        startCalendar = Calendar.getInstance()
        endCalendar = Calendar.getInstance()
        startCalendar.add(Calendar.DAY_OF_MONTH, -7)

        startDate = formatDate(startCalendar.timeInMillis)
        endDate = formatDate(endCalendar.timeInMillis)

        binding.textView12.text = formatDate(startCalendar.timeInMillis)
        binding.textView13.text = formatDate(endCalendar.timeInMillis)

        binding.btnStartDate.text = formatDate(startCalendar.timeInMillis)
        binding.btnEndDate.text = formatDate(endCalendar.timeInMillis)

        getBarData(startDate,endDate)

        binding.btnStartDate.setOnClickListener {
            showDatePicker(true)
        }
        binding.btnEndDate.setOnClickListener {
            showDatePicker(false)
        }

        binding.btnSwitchChart.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                chartType = "pie"
                barChart.visibility = View.GONE
                pieChart.visibility = View.VISIBLE
                getPieData(startDate, endDate)
            } else {
                chartType = "bar"
                barChart.visibility = View.VISIBLE
                pieChart.visibility = View.GONE
                getBarData(startDate, endDate)
            }
        }

    }

    private fun showDatePicker(start: Boolean) {
        val calendar = Calendar.getInstance()
        val datePickerDialog = DatePickerDialog(
            this.requireContext(),
            DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
                if (start) {
                    startCalendar.set(Calendar.YEAR, year)
                    startCalendar.set(Calendar.MONTH, month)
                    startCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    binding.btnStartDate.text = formatDate(startCalendar.timeInMillis)
                    binding.textView12.text = formatDate(startCalendar.timeInMillis)
                    startDate = formatDate(startCalendar.timeInMillis)
                    if (chartType == "bar") {
                        getBarData(startDate, endDate)
                    }
                    else {
                        getPieData(startDate, endDate)
                    }
                } else {
                    endCalendar.set(Calendar.YEAR, year)
                    endCalendar.set(Calendar.MONTH, month)
                    endCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    binding.btnEndDate.text = formatDate(endCalendar.timeInMillis)
                    binding.textView13.text = formatDate(endCalendar.timeInMillis)
                    endDate = formatDate(endCalendar.timeInMillis)
                    if (chartType == "bar") {
                        getBarData(startDate, endDate)
                    }
                    else {
                        getPieData(startDate, endDate)
                    }
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    private fun formatDate(timestamp: Long): String {
        val formatter = SimpleDateFormat("d.M.yyyy", Locale.getDefault())
        return formatter.format(Date(timestamp))
    }


    fun getPieData(startDate: String, endDate: String) {
        val dateRange = getDateRange(startDate, endDate)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        val userDataRef = FirebaseFirestore.getInstance().collection("user").document(uid).collection("userData").document(uid)
        val drinkByType = mutableMapOf<String, Double>()

        val tasks = mutableListOf<Task<Double>>()

        for (date in dateRange) {
            tasks.add(userDataRef.collection(date).get().continueWith { task ->
                var totalDrinkValue = 0.0

                for (document in task.result!!) {
                    val drink = document.get("drink").toString()
                    val drinkValue = document.get("drinkValue").toString().toDouble()

                    totalDrinkValue += drinkValue

                    if (drinkByType.containsKey(drink)) {
                        drinkByType[drink] = drinkByType[drink]!! + drinkValue
                    } else {
                        drinkByType[drink] = drinkValue
                    }
                }

                totalDrinkValue
            })
        }

        Tasks.whenAll(tasks).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                updatePieChart(drinkByType)
            } else {
                // Handle error here
            }
        }
    }

    private fun updateBarChart(drinkValuesByDate: MutableMap<String, Double>) {
        val barEntries = mutableListOf<BarEntry>()
        var i = 0f
        val uid = mFirebaseAuth.currentUser!!.uid

        getLimit(uid) { limit ->
            val colors = mutableListOf<Int>()
            for ((date, totalDrinkValue) in drinkValuesByDate) {
                val color = if (totalDrinkValue > limit) Color.BLUE else Color.RED
                barEntries.add(BarEntry(i, totalDrinkValue.toFloat()))
                colors.add(color)
                i++
            }

            val barDataSet = BarDataSet(barEntries, "Drink Value")
            barDataSet.colors = colors
            barDataSet.valueTextColor = Color.BLACK
            barDataSet.valueTextSize = 14f
            barDataSet.valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return "${value.toInt()} ml"
                }
            }

            val barData = BarData(barDataSet)

            val yAxis = barChart.axisLeft

            val limitLine = LimitLine(limit)
            limitLine.lineWidth = 2f
            limitLine.lineColor = Color.GREEN
            limitLine.textColor = Color.GREEN
            limitLine.textSize = 10f

            yAxis.addLimitLine(limitLine)

            barChart.data = barData
            barChart.xAxis.textSize = 12f
            barChart.xAxis.valueFormatter = IndexAxisValueFormatter(drinkValuesByDate.keys.toList())
            barChart.xAxis.granularity = 1f
            barChart.xAxis.position = XAxis.XAxisPosition.BOTTOM
            barChart.xAxis.setDrawGridLines(false)

            barChart.axisLeft.textSize = 12f

            barChart.axisRight.isEnabled = false
            barChart.legend.isEnabled = false
            barChart.description.isEnabled = false
            barChart.animateY(1000)
            barChart.invalidate()
        }
    }

    private fun getLimit(uid: String, callback: (Float) -> Unit) {
        db.collection("user").document(uid).collection("userSettings").document("dailyIntake")
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val doc = task.result
                    val limit = doc.getString("daylimit").toString().toFloat()
                    callback(limit)
                } else {
                    // Log.d(TAG, "FEHLER: Daten lesen ", task.exception)
                }
            }
    }



    private fun updatePieChart(drinkData: Map<String, Double>) {
        val entries = mutableListOf<PieEntry>()
        val colors = mutableListOf<Int>()
        var i = 0

        for ((drink, drinkValue) in drinkData) {
            entries.add(PieEntry(drinkValue.toFloat(), drink))
            colors.add(ColorTemplate.COLORFUL_COLORS[i % ColorTemplate.COLORFUL_COLORS.size])
            i++
        }

        val dataSet = PieDataSet(entries, "")
        dataSet.colors = colors
        dataSet.valueTextSize = 14f
        dataSet.valueTextColor = Color.BLACK
        dataSet.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return "${value.toInt()} ml"
            }
        }
        val data = PieData(dataSet)

        pieChart.data = data
        pieChart.animateY(1000)
        pieChart.legend.isEnabled = true
        pieChart.legend.textSize = 16f
        pieChart.legend.form = Legend.LegendForm.CIRCLE
        pieChart.legend.formSize = 14f
        pieChart.legend.xEntrySpace = 5f
        pieChart.legend.yEntrySpace = 5f
        pieChart.legend.textColor = Color.BLACK
        pieChart.legend.verticalAlignment = Legend.LegendVerticalAlignment.TOP
        pieChart.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.LEFT
        pieChart.legend.orientation = Legend.LegendOrientation.VERTICAL
        pieChart.legend.setDrawInside(false)
        pieChart.legend.yOffset = 0f
        pieChart.legend.xOffset = 10f
        pieChart.legend.yEntrySpace = 0f
        pieChart.description.isEnabled = false
        pieChart.setEntryLabelColor(Color.BLACK)
        pieChart.setEntryLabelTextSize(14f)
        pieChart.invalidate()
    }



    fun getBarData(startDate: String, endDate: String) {
        val dateRange = getDateRange(startDate, endDate)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        val userDataRef = FirebaseFirestore.getInstance().collection("user").document(uid).collection("userData").document(uid)
        val drinkValuesByDate = mutableMapOf<String, Double>()

        val tasks = mutableListOf<Task<Double>>()

        for (date in dateRange) {
            tasks.add(userDataRef.collection(date).get().continueWith { task ->
                var totalDrinkValue = 0.0
                for (document in task.result!!) {
                    totalDrinkValue += document.get("drinkValue").toString().toDouble()
                }
                drinkValuesByDate[date] = totalDrinkValue
                totalDrinkValue
            })
        }

        Tasks.whenAllSuccess<Double>(tasks).addOnSuccessListener {
            val sortedDrinkValuesByDate = drinkValuesByDate.toSortedMap(compareBy {
                SimpleDateFormat("d.M.yyyy", Locale.getDefault()).parse(it)
            })
            updateBarChart(sortedDrinkValuesByDate)
        }
    }


    private fun getDateRange(startDate: String, endDate: String): List<String> {
        val dateRange = mutableListOf<String>()
        val start = SimpleDateFormat("d.M.yyyy", Locale.getDefault()).parse(startDate)
        val end = SimpleDateFormat("d.M.yyyy", Locale.getDefault()).parse(endDate)

        val calendar = Calendar.getInstance()
        calendar.time = start
        while (calendar.time.before(end) || calendar.time.equals(end)) {
            dateRange.add(SimpleDateFormat("d.M.yyyy", Locale.getDefault()).format(calendar.time))
            calendar.add(Calendar.DATE, 1)
        }

        return dateRange.sortedWith(Comparator { date1, date2 ->
            SimpleDateFormat("d.M.yyyy", Locale.getDefault()).parse(date1).compareTo(
                SimpleDateFormat("d.M.yyyy", Locale.getDefault()).parse(date2)
            )
        })
    }




}


