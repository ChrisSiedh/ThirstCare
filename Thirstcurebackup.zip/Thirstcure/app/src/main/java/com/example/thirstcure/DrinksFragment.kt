package com.example.thirstcure

import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.thirstcure.databinding.FragmentDrinksBinding
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import java.text.ParseException
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.*
import kotlin.collections.ArrayList


class DrinksFragment : Fragment(R.layout.fragment_drinks) {

    private var _binding: FragmentDrinksBinding? = null
    private val binding get() = _binding!!

    private val mFirebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private var db:FirebaseFirestore = FirebaseFirestore.getInstance()

    private var list = ArrayList <String> ()
    private lateinit var adapter : ArrayAdapter<String>



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentDrinksBinding.inflate(inflater, container, false)
        adapter = ArrayAdapter( this.requireContext(),android.R.layout.simple_list_item_1,list)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        binding.lvDrinks.adapter = adapter
        loadDrinks()

        //FAB
        binding.fabAddDrink.setOnClickListener{
            val builder = AlertDialog.Builder(activity)
            val inflater = layoutInflater
            val dialogLayout:View = inflater.inflate(R.layout.edit_text_layout, null)
            val editText = dialogLayout.findViewById<EditText>(R.id.et_pwreset)
            editText.hint = getString(R.string.et_drink_hint)

            with(builder){
                setTitle(R.string.dialog_drink_title)
                setPositiveButton(R.string.dialog_drink_pos){dialog, which ->
                    val drink = editText.text.toString().trim()
                    if (drink.isNotEmpty()) {
                        insertDrinkInDB(drink)
                        list.add(drink)
                        adapter.notifyDataSetChanged()
                    } else {
                    //
                    }
                }
                setNegativeButton(R.string.dialog_neg){dialog, which ->

                }
                setView(dialogLayout)
                show()
            }
        }


        //Listview Item anwählen
        binding.lvDrinks.setOnItemClickListener { adapterView, view, i, l ->

            //Hier erhalten wir das angeklickte item aus der Liste als string
            val s: String = binding.lvDrinks.getItemAtPosition(i).toString()
            val selected1 = i

            val builder = AlertDialog.Builder(activity)
            val inflater = layoutInflater
            val dialogLayout:View = inflater.inflate(R.layout.edit_text_layout, null)
            val editText = dialogLayout.findViewById<EditText>(R.id.et_pwreset)
            editText.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            editText.hint = getString(R.string.et_drink_hint)

            with(builder){
                setTitle("Wie viel haben Sie getrunken?")
                setPositiveButton("R.string.dialog_drink_pos"){dialog, which ->
                    val drinkValue = editText.text.toString().trim()
                    if (drinkValue.isNotEmpty()) {
                        saveDrinkValue(s,drinkValue)
                    } else {
                        //
                    }
                }
                setNegativeButton(R.string.dialog_neg){dialog, which ->

                }
                setView(dialogLayout)
                show()
           }
        }

    }

    private fun insertDrinkInDB(drink: String){
        val uid = mFirebaseAuth.currentUser!!.uid

        val drinks = userDrinks()
        drinks.setDrink(drink)

        db.collection("user").document(uid).collection("userDrinks").add(drinks)
            .addOnSuccessListener { Toast.makeText(activity,"Erfolg",Toast.LENGTH_SHORT).show() }
            .addOnFailureListener{ Toast.makeText(activity,"fehler",Toast.LENGTH_SHORT).show() }

    }

    private fun saveDrinkValue(drink: String, drinkValue: String){
        val uid = mFirebaseAuth.currentUser!!.uid
        var datetimestamp: Date? = null

        val dateFormat = SimpleDateFormat ("d.M.yyyy")
        val currentDate = dateFormat.format(Date()).toString()

        try {
            datetimestamp = dateFormat.parse(currentDate)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        val drinkData = userData()
        drinkData.setDrink(drink)
        drinkData.setValue(drinkValue)
        drinkData.setDateTimestamp(datetimestamp)

        db.collection("user").document(uid).collection("userData").document(uid).collection(currentDate).add(drinkData)
            .addOnSuccessListener { Toast.makeText(activity,"Erfolg",Toast.LENGTH_SHORT).show() }
            .addOnFailureListener{ Toast.makeText(activity,"fehler",Toast.LENGTH_SHORT).show() }
    }

    private fun loadDrinks() {
        val uid = mFirebaseAuth.currentUser!!.uid

        db.collection("user").document(uid).collection("userDrinks")
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    updateListView(task)
                } else {
                   // Log.d(TAG, "FEHLER: Daten lesen ", task.exception)
                }
            }
    }


    private fun updateListView(task: Task<QuerySnapshot>) {
        // Einträge in dbList kopieren, um sie im ListView anzuzeigen
        list = ArrayList()
        // Diese for schleife durchläuft alle Documents der Abfrage
        for (document in task.result!!) {
            (list as ArrayList<userDrinks>).add(document.toObject(userDrinks::class.java))
            //Log.d(TAG, document.id + " => " + document.data)
        }
        // jetzt liegt die vollständige Liste vor und
        // kann im ListView angezeigt werden
        adapter = ArrayAdapter( this.requireContext(),android.R.layout.simple_list_item_1,list)
        binding.lvDrinks.adapter = adapter
    }


}